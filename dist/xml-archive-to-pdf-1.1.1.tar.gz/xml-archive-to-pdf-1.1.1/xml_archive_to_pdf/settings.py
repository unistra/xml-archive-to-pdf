ATTR_NAME = "name"
ATTR_STYLE = "style"
ATTR_STYLE_TABLE = "table"
ATTR_STYLE_TITLE = "title"
EVENT_START = "start"
EVENT_END = "end"
SPACE_UNIT = 12
DEFAULT_FONT = "Helvetica"
